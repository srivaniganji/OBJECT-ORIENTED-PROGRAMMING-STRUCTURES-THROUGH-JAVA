public class ExceptionHandling {
    public ExceptionHandling(String string) {
    }

    public static void main(String args[]) {

        System.out.println("<--Start-->");
        int i = 20;
        int j = 10;
        String str = null;
        int nums[] = new int[5];

        try {
            System.out.println("i divisible by j = " + i / j);
            System.out.println(nums[0]);
            System.out.println(str.length());
        } catch (ArithmeticException e) {
            System.out.println(e);
        } catch (IndexOutOfBoundsException e) {
            System.out.println(e);
        } catch (Exception e) {
            System.out.println(e);
        }

        System.out.println("<--End-->");
    }
}
