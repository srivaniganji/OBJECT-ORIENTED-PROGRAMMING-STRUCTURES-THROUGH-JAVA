/*Write a java program that prints all real and imaginary solutions to the quadratic equation ax2+bx+c=0. Read in a, b,c and use the quadratic formula. */

import java.util.*;
import java.lang.Math;

public class Roots {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.println("Enter a: ");
        int a = In.nextInt();
        System.out.println("Enter b: ");
        int b = In.nextInt();
        System.out.println("Enter c: ");
        int c = In.nextInt();
        double det = (b * b) - (4 * a * c);
        double root1, root2, img;
        if (det == 0) {
            System.out.println("Two Real and Equal Roots are: ");
            root1 = root2 = (-b) / (2.0 * a);
            System.out.println(root1 + " ," + root2);
        } else if (det > 0) {
            System.out.println("Two Real and Distinct Roots are: ");
            root1 = (-b) / (2.0 * a) + (Math.sqrt(det) / (2.0 * a));
            root2 = (-b) / (2.0 * a) - (Math.sqrt(det) / (2.0 * a));
            System.out.println(root1 + " ," + root2);
        } else {
            System.out.println("Two imaginary Roots are: ");
            root1 = (-b) / (2.0 * a);
            root2 = (-b) / (2.0 * a);
            det = det * -1;
            img = (Math.sqrt(det) / (2.0 * a));
            System.out.println(root1 + "+" + "i" + img + " ," + root2 + "-" + "i" + img);
        }
        In.close();
    }
}
