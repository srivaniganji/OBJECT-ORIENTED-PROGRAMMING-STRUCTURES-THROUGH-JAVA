// UpCasting and DownCasting

class Shape {
    public void show() {
        System.out.println("This is Shape!");
    }

    public void display() {
        System.out.println("In Shape!");
    }
}

class Circle extends Shape {
    public void show() {
        System.out.println("This is Circle!");
    }
}

public class Casting {
    public static void main(String args[]) {

        // UpCasting
        Shape S = new Circle();
        S.show();
        S.display();

        // DownCasting
        Circle C = (Circle) S;
        C.show();
    }
}
