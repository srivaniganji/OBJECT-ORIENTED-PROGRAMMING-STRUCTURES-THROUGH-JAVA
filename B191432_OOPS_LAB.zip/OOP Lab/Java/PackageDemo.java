//package p2;

import Calculator.Calc;
import Calculator.AdvCalc;

public class PackageDemo {
    public static void main(String args[]) {
        Calc C = new Calc();
        System.out.println("Addition = " + C.add(2, 3));
        System.out.println("Subtraction = " + C.sub(5, 4));

        AdvCalc Ac = new AdvCalc();
        System.out.println("Multiplication = " + Ac.mul(4, 5));
        System.out.println("Division = " + Ac.div(6, 3));
    }
}
