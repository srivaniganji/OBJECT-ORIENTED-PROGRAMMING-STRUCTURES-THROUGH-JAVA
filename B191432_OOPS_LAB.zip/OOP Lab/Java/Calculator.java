/*Write a java program to implement calculator operations. */

import java.util.*;

public class Calculator {

    public int Addition(int x, int y) {
        System.out.print("After Addition Result = ");
        return x + y;
    }

    public int Subtraction(int x, int y) {
        System.out.print("After Subtraction Result = ");
        return x - y;
    }

    public int Multiplication(int x, int y) {
        System.out.print("After Multiplication Result = ");
        return x * y;
    }

    public double Division(int x, int y) {
        System.out.print("After Division Result = ");
        return x / y;
    }

    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.println(
                "Enter 1 for Addition\nEnter 2 for Subtraction\nEnter 3 for Multiplication\nEnter 4 for Division\n");
        System.out.print("Enter choice: ");
        int ch = In.nextInt();
        System.out.print("Enter first number: ");
        int x = In.nextInt();
        System.out.print("Enter second number: ");
        int y = In.nextInt();
        Calculator calci = new Calculator();
        switch (ch) {
            case 1:
                System.out.println(calci.Addition(x, y));
                break;
            case 2:
                System.out.println(calci.Subtraction(x, y));
                break;
            case 3:
                System.out.println(calci.Multiplication(x, y));
                break;
            case 4:
                System.out.println(calci.Division(x, y));
                break;
            default:
                System.out.println("Invalid Operator Entered!");
        }
        In.close();
    }
}
