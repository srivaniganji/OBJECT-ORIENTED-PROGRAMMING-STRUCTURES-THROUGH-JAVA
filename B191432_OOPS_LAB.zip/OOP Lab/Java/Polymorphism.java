/*
//Example-1

class Calculator {

    public int add(int a, int b) {
        return a + b;
    }

    public int add(int a, int b, int c) {
        return a + b + c;
    }

    public double add(int a, double b) {
        return a + b;
    }

    public String add(String a, String b) {
        return a + b;
    }
}

public class Polymorphism {

    public static void main(String args[]) {
        Calculator C = new Calculator();
        System.out.println(C.add(3, 4));
        System.out.println(C.add(1, 2, 3));
        System.out.println(C.add(5, 5.0));
        System.out.println(C.add("Hello", " World"));
    }
}
*/

//Example-2

class Student {
    void print(String name, int age) {
        System.out.println(name + " " + age);
    }

    void print(String name) {
        System.out.println(name);
    }

    void print(int age) {
        System.out.println(age);
    }
}

public class Polymorphism {
    public static void main(String args[]) {
        Student s = new Student();
        s.print("Srivani");
        s.print(19);
        s.print("Sindhuja", 18);
    }
}
