
// import java.util.ArrayList;
// import java.util.List;
import java.util.*;

class List1 {
    public static void main(String args[]) {
        List<Integer> list = new ArrayList<>(5);
        System.out.println("Initial Size = " + list.size());
        for (int i = 0; i < 5; i++) {
            list.add(i);
        }
        // list.add();
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
        System.out.println("Size = " + list.size());
    }
}