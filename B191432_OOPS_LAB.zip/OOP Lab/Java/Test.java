import java.io.*;

public class Test {
    public static void main(String args[]) {
        try {
            throw new IOException("Hello");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}