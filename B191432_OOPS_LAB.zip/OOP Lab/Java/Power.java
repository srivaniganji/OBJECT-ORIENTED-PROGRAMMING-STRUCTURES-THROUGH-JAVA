//Calculate x to the power n, given x and n;

import java.util.*;

public class Power {

    public static int calculatePower(int x, int n) {
        int pow = 1;
        for (int i = 1; i <= n; i++) {
            pow *= x;
        }
        return pow;
    }

    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.print("Enter x: ");
        int x = In.nextInt();
        System.out.print("Enter n: ");
        int n = In.nextInt();
        System.out.println("x to the power n = " + calculatePower(x, n));
        In.close();
    }
}
