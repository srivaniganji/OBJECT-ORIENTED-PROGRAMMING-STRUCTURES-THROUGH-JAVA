public class Wrapper {
    public static void main(String args[]) {
        int num1 = 5;
        System.out.println("int value = " + num1);

        Integer num2 = num1; // Auto-Boxing
        System.out.println("Integer Object value = " + num2);

        int num3 = num2; // Auto-Unboxing
        System.out.println("Parsed int value = " + num3);
    }
}
