//Final Keyword - Variable, Method, Class

class Flower {
    public final void show() {
        System.out.println("This is Flower!");
    }
}

final class Rose extends Flower {

    // As the method in Parent class is final, we cannot override.

    // public void show() {
    // System.out.println("Thsi is Rose Flower!");
    // }

    public void display() {
        System.out.println("This is Rose Flower!");
    }
}

// As the parent class of the redRose i.e., Rose is final, we cannot extend it.

// class redRose extends Rose {
// public void show() {
// System.out.println("This is Red Rose!");
// }
// }

public class Final {
    public static void main(String args[]) {

        final int Num = 10;
        // Num = 100; --> this will throw an error as Num is final.
        System.out.println("Final Number = " + Num);

        Rose R = new Rose();
        R.show();
        R.display();
    }
}
