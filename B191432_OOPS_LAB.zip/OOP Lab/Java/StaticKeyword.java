class Student {
    int roll;
    String name;
    static String role;

    static void show(Student s) {
        System.out.println(s.roll + " " + s.name + " " + role);
    }
}

public class StaticKeyword {
    public static void main(String args[]) {
        Student s1 = new Student();
        s1.roll = 1;
        s1.name = "ghfjkd";
        Student.role = "Student";
        // System.out.println(s1.roll + " " + s1.name + " " + s1.role);
        Student.show(s1);

        Student s2 = new Student();
        s2.roll = 2;
        s2.name = "fghjk";
        Student.role = "Teacher";
        // System.out.println(s2.roll + " " + s2.name + " " + s2.role);
        Student.show(s2);

        Student.role = "2456789";
        Student.show(s1);
        Student.show(s2);

    }
}
