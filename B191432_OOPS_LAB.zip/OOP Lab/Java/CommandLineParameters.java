public class CommandLineParameters {
    public static void main(String args[]) {
        for (int i = 0; i < args.length - 1; i++) {
            for (int j = 0; j < args.length - i - 1; j++) {
                String a = args[j];
                String b = args[j + 1];
                if (a.compareTo(b) > 0) {
                    args[j] = b;
                    args[j + 1] = a;
                }
            }
        }
        for (int i = 0; i < args.length; i++) {
            System.out.println(args[i]);
        }
    }
}