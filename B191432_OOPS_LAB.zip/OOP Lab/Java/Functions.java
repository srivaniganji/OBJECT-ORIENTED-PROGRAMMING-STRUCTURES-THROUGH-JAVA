import java.util.*;

public class Functions {
    public static void printMyName(String name) {
        System.out.println("Hello " + name);
    }

    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.print("Enter your Name: ");
        String name = In.next();
        printMyName(name);
        In.close();
    }
}
