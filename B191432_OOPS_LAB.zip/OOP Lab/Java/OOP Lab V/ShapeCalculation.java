/* Create an abstract class Shape which calculate the area and volume of 2-d and 
3-d shapes with abstract methods getArea() and getVolume(). 
Reuse this class to calculate the area and volume of square, circle, cube and sphere. */

abstract class Shape {
    abstract double getArea();

    abstract double getVolume();
}

class Square extends Shape {
    private double side;

    public Square(double side) {
        this.side = side;
    }

    @Override
    double getArea() {
        return side * side;
    }

    @Override
    double getVolume() {
        return 0; // A square is a 2D shape, so volume is not applicable
    }
}

class Circle extends Shape {
    private double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    double getArea() {
        return Math.PI * radius * radius;
    }

    @Override
    double getVolume() {
        return 0; // A circle is a 2D shape, so volume is not applicable
    }
}

class Cube extends Shape {
    private double side;

    public Cube(double side) {
        this.side = side;
    }

    @Override
    double getArea() {
        return 6 * side * side;
    }

    @Override
    double getVolume() {
        return side * side * side;
    }
}

class Sphere extends Shape {
    private double radius;

    public Sphere(double radius) {
        this.radius = radius;
    }

    @Override
    double getArea() {
        return 4 * Math.PI * radius * radius;
    }

    @Override
    double getVolume() {
        return (4.0 / 3.0) * Math.PI * radius * radius * radius;
    }
}

public class ShapeCalculation {
    public static void main(String[] args) {
        // Example usage
        Square square = new Square(5.0);
        Circle circle = new Circle(3.0);
        Cube cube = new Cube(4.0);
        Sphere sphere = new Sphere(2.0);

        displayShapeInfo(square);
        displayShapeInfo(circle);
        displayShapeInfo(cube);
        displayShapeInfo(sphere);
    }

    private static void displayShapeInfo(Shape shape) {
        System.out.println("Area: " + shape.getArea());
        System.out.println("Volume: " + shape.getVolume());
        System.out.println();
    }
}
