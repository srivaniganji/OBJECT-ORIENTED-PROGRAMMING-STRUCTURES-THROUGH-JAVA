/* Create an abstract class Employee with abstract method getAmount() which 
displays the amount paid to employee. 
Reuse this class to calculate the amount to be paid to WeeklyEmployees and 
HourlyEmployees according to no. of hours and total hours for HourlyEmployee
and no. of weeks and total weeks for WeeklyEmployee.
 */

import java.util.*;

abstract class Employee {
    abstract int getAmount();
}

class weeklyEmployee extends Employee {

    int weeks, amountPerWeek;

    weeklyEmployee(int weeks, int amountPerWeek) {
        this.weeks = weeks;
        this.amountPerWeek = amountPerWeek;
    }

    int getAmount() {
        return 4 * weeks * amountPerWeek;
    }
}

class hourlyEmployee extends Employee {

    int hours, amountPerHour;

    hourlyEmployee(int hours, int amountPerHour) {
        this.hours = hours;
        this.amountPerHour = amountPerHour;
    }

    int getAmount() {
        return 30 * hours * amountPerHour;
    }
}

public class EmployeeSalary {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        int w, h, apw, aph;
        System.out.println("Enter number of weeks weekly employee worked: ");
        w = In.nextInt();
        System.out.println("Enter amount paid for a week: ");
        apw = In.nextInt();
        System.out.println("Enter number of hours hourly employee worked: ");
        h = In.nextInt();
        System.out.println("Enter amount paid for an hour: ");
        aph = In.nextInt();
        weeklyEmployee we = new weeklyEmployee(w, apw);
        hourlyEmployee he = new hourlyEmployee(h, aph);
        System.out.println("Amount that is paid to a weekly employee = " + we.getAmount());
        System.out.println("Amount that is paid to an hourly employee = " + he.getAmount());
        In.close();
    }
}
