package Threads;

class MultipleThreads extends Thread { // class MultipleThreads implements Runnable
    public void run() {
        System.out.println("Thread " + Thread.currentThread().threadId() + " running..");
    }

}

public class ThreadsDemo {
    public static void main(String args[]) throws InterruptedException {
        int n = 5;
        for (int i = 0; i < n; i++) {
            MultipleThreads t = new MultipleThreads();
            t.start();
            Thread.sleep(100);
        }
        // t.start();
    }
}
