package Threads;

// Without Synchronization

class Test {
    void printTest(int n) {
        for (int i = 1; i <= 5; i++) {
            System.out.println((n * i));
            try {
                Thread.sleep(10);
            } catch (Exception e) {
                System.out.println("Exception caught!");
            }
        }
    }
}

class MyThread extends Thread {
    Test t;

    MyThread(Test t) {
        this.t = t;
    }

    public void run() {
        t.printTest(5);
    }
}

class MyThread1 extends Thread {
    Test t;

    MyThread1(Test t) {
        this.t = t;
    }

    public void run() {
        t.printTest(100);
    }
}

public class TestSynchronization {
    public static void main(String args[]) {
        Test t = new Test();
        MyThread thread = new MyThread(t);
        MyThread1 thread1 = new MyThread1(t);
        thread.start();
        thread1.start();
    }
}
