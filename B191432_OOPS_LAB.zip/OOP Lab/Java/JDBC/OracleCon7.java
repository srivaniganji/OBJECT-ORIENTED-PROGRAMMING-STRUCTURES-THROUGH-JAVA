    import java.sql.*;  
//import oracle.jdbc.*;
    class OracleCon7{  
    public static void main(String args[]){  

    try{  
    //step1 load the driver class  
    Class.forName("oracle.jdbc.driver.OracleDriver");  
      
    //step2 create  the connection object  
    Connection con=DriverManager.getConnection(  
    "jdbc:oracle:thin:@localhost:1521:XE","system","geeta");  //
      
    //step3 create the statement object  
    CallableStatement stmt=con.prepareCall("{call q(?,?)}");  
       stmt.setString(1,"sam");
       stmt.setInt(2,56);

    //step4 execute query  
    stmt.execute();  
  
      
    //step5 close the connection object  
     stmt.close();
    con.close();  
      
    }catch(Exception e){ System.out.println(e);}  
      
    }  
    }  