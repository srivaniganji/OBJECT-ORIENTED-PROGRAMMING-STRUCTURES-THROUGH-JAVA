    import java.sql.*;  
//import oracle.jdbc.*;
    class OracleCon4{  
    public static void main(String args[]){  
String name=args[0];
int id=Integer.parseInt(args[1]);
    try{  
    //step1 load the driver class  
    Class.forName("oracle.jdbc.driver.OracleDriver");  
      
    //step2 create  the connection object  
    Connection con=DriverManager.getConnection(  
    "jdbc:oracle:thin:@localhost:1521:XE","system","dbms");  //
      
    //step3 create the statement object  
    PreparedStatement stmt=con.prepareStatement("insert into emp values(?,?)");  
      
stmt.setString(1,name);
stmt.setInt(2,id);

    //step4 execute query  
    stmt.executeUpdate();  
  
      
    //step5 close the connection object  
    con.close();  
      
    }catch(Exception e){ System.out.println(e);}  
      
    }  
    }  