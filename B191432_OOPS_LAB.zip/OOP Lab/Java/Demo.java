//Method Overloading

//import java.lang.*;

class Calculator {

    public int add(int a, int b) {
        return a + b;
    }

    public int add(int a, int b, int c) {
        return a + b + c;
    }

    public double add(int a, double b) {
        return a + b;
    }

    public String add(String a, String b) {
        return a + b;
    }
}

public class Demo {

    public static void main(String args[]) {
        Calculator C = new Calculator();
        System.out.println(C.add(3, 4));
        System.out.println(C.add(1, 2, 3));
        System.out.println(C.add(5, 5.0));
        System.out.println(C.add("Hello", " World"));
    }
}