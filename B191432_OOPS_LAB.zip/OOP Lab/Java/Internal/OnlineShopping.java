/*
 * New year welcomes with a Grand sale from topmost E-commerce sites Amazon
and Flipkart. Design an application that prompts user to enter product name,
company it belongs to and the quantity(Note : you can input more if your
application requires) and suggest him/her(cost effective) where to buy the product
either from Amazon or E-commerce.
Amazon offers 10% Discount for HDFC credit card holders and 15% discount on
purchase above 50,000.
Flipkart offers 30% Discount if he/she is a RGUKT student and 5% discount on
purchase above 30,000.
 */

import java.util.*;

class eCommerce {
    String productName, companyName;
    int quantity, price;
    float totalPrice;
    boolean isHDFCCard = false, isRGUKTian = false;
    Scanner In = new Scanner(System.in);

    eCommerce() {
        /*
         * this.companyName = companyName;
         * this.productName = productName;
         * this.quantity = quantity;
         * this.price = price;
         */

        System.out.print("Enter Product name: ");
        productName = In.next();
        System.out.print("Enter Company name: ");
        companyName = In.next();
        System.out.print("Enter Quantity: ");
        quantity = In.nextInt();
        System.out.print("Enter price: ");
        price = In.nextInt();
        System.out.print("Is your card HDFC: ");
        isHDFCCard = In.nextBoolean();
        System.out.print("Are you RGUKTian: ");
        isRGUKTian = In.nextBoolean();
    }

    float getTotalPrice() {
        totalPrice = price * quantity;
        if (companyName == "Amazon") {
            if (totalPrice >= 50000) {
                totalPrice -= (0.15 * totalPrice);
            } else if (isHDFCCard) {
                totalPrice -= (0.1 * totalPrice);
            }
        } else {
            if (isRGUKTian) {
                totalPrice -= (0.3 * totalPrice);
            } else if (totalPrice >= 30000) {
                totalPrice -= (0.05 * totalPrice);
            }
        }
        return totalPrice;
    }
}

public class OnlineShopping {
    public static void main(String args[]) {
        System.out.println("\n Welcome to Online Shopping\n");
        System.out.println("--Enter details of Product 1--");
        eCommerce product1 = new eCommerce();
        System.out.println("--Enter details of Product 2--");
        eCommerce product2 = new eCommerce();

        float price1 = product1.getTotalPrice();
        float price2 = product2.getTotalPrice();
        System.out.println("Total Cost of Amazon = " + price1);
        System.out.println("Total Cost of FlipKart = " + price2);

        if (price1 < price2) {
            System.out.println("Suggested Company is " + product1.companyName + " to buy the product!");
        } else if (price1 > price2) {
            System.out.println("Suggested Company is " + product2.companyName + " to buy the product!");
        } else {
            System.out.println("Any company is OK to buy the product!");
        }
    }
}
