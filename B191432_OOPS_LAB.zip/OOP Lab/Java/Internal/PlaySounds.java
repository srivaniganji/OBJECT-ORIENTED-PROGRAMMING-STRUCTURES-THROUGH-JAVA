import java.util.Scanner;

import Sounds.PodCast;

public class PlaySounds {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        PodCast p = new PodCast();
        System.out.print("Enter 1 to play Dolby sounds and 2 to play PodCast: ");
        int choice = In.nextInt();
        switch (choice) {
            case 1:
                p.playDolby();
                break;
            case 2:
                p.playPodcast();
                break;
            default:
                System.out.println("Invalid choice!");
        }
        In.close();
    }
}
