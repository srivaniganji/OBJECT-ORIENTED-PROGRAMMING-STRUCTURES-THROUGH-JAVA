package Sounds;

public class PodCast implements Dolby {
    public void playDolby() {
        System.out.println("Playing Dolby Sound..");
    }

    public void playPodCast() {
        System.out.println("Playing PodCast Sound..");
    }

    @Override
    public void playPodcast() {
        throw new UnsupportedOperationException("Unimplemented method 'playPodcast'");
    }
}
