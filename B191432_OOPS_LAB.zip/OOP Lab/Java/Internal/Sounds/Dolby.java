package Sounds;

public interface Dolby {
    void playDolby();

    void playPodCast();
}