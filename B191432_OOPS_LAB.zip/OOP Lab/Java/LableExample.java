import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LableExample {
    public static void main(String[] args) {
        Frame frame = new Frame("AWT Example");
        frame.setSize(400, 300);
        frame.setLayout(new FlowLayout());
        frame.setVisible(true);

        TextField text = new TextField("Enter your name");
        frame.add(text);

        Button button = new Button("Click me!");
        frame.add(button);

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                text.setText("Srivani");
            }
        });
    }
}
