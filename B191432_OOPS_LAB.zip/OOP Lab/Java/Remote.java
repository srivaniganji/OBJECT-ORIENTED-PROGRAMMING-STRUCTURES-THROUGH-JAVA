package TVRemote;

public interface Remote {

}