class Student {
    String name;
    int id;

    public void printStudentInfo() {
        System.out.println(this.name);
        System.out.println(this.id);
    }

    // Non-parameterized Constructor
    Student() {
        System.out.println("--Non-parameterized Constructor--");
    }

    // Parameterized Constructor
    Student(String name, int id) {
        System.out.println("--Parameterized Constructor--");
        this.name = name;
        this.id = id;
    }

    // Copy Constructor
    Student(Student s) {
        System.out.println("--Copy class Constructor--");
        this.name = s.name;
        this.id = s.id;
    }
}

public class Students {
    public static void main(String args[]) {
        Student s1 = new Student();
        s1.name = "Srivani";
        s1.id = 17;
        s1.printStudentInfo();

        Student s2 = new Student("Sindhuja", 15);
        s2.printStudentInfo();

        Student s3 = new Student(s2);
        s3.printStudentInfo();
    }
}
