package Sounds;

public interface Dolby {
    void playPodcast();

    void playDolby();
}
