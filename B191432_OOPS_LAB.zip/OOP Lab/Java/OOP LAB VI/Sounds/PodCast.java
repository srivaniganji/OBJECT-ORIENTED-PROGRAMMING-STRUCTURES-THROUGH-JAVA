package Sounds;

public class PodCast implements Dolby {
    public void playPodcast() {
        System.out.println("Playing Podcast sound");
    }

    public void playDolby() {
        System.out.println("Playing Dolby sound");
    }
}
