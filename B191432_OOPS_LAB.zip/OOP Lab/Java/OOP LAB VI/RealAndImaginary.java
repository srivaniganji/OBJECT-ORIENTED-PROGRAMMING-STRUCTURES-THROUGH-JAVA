/*
a. Include the package complex
b. Create a class Arith and declare rp, ip as integer.
c. Define the function Arith(),set rp and ip to 0
d. Another function Arith(int rp,in tip) set this.rp=rp and this.ip=ip
e. create a method add() pass arguments with arith a1 and arith a2
f. add a1.rp and a2.rp store in rp.
g. Similarly add a1.ip and a2.ip and store in ip.
h. Create a function sub(arith a1,arith a2)
i. Subtract a1.rp and a2.rp store it in rp.
j. Subtract a1.ip and a2.ip store it in ip.
k. Import the package and calculate the addition and subtraction of two complex 
numbers.

Sample I/p and O/p:
Enter real part and imaginary part of 1st complex no: 10 5
Enter real part and imaginary part of 2
nd complex no: 3 6
a1=10+5i
a2=3+6i
Added value: 13+11i
Subtracted value: 7-1i 
*/

import Arith.*;
import java.util.*;

public class RealAndImaginary {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        Calculate C = new Calculate();
        System.out.println("Enter real and imaginary parts of first number: ");
        int i1 = In.nextInt();
        int i2 = In.nextInt();
        System.out.println("Enter real and imaginary parts of second number: ");
        int j1 = In.nextInt();
        int j2 = In.nextInt();
        System.out.println("\nGiven: ");
        System.out.println("x = " + i1 + "+" + i2 + "i");
        System.out.println("y = " + j1 + "+" + j2 + "i");
        C.add(i1, i2, j1, j2);
        C.subtract(i1, i2, j1, j2);
        In.close();
    }
}
