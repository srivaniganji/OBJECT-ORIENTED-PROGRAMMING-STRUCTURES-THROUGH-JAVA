import ReservationCostPackage.*;

public class Reservation {
    public static void main(String[] args) {
        Passenger[] passengers = {
                new Child(),
                new SeniorCitizen(),
                new Student(),
                new Citizen()
        };

        ReservationCost reservationCost = new ReservationCalculator();
        double totalFare = reservationCost.total_fare(passengers);

        System.out.println("Total Fare: " + totalFare);
    }
}
