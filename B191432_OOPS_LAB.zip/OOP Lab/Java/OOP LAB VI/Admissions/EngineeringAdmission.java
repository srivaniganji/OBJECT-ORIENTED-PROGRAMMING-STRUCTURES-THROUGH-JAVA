package Admissions;

public class EngineeringAdmission implements AdmissionEligibility {

    @Override
    public boolean checkEligibility(int mathsMarks, int physicsMarks, int chemistryMarks, int englishMarks) {
        double totalPercentage = calculatePercentage(mathsMarks, physicsMarks, chemistryMarks, englishMarks);

        return mathsMarks >= 90 && physicsMarks >= 95 && chemistryMarks >= 70 && englishMarks >= 80
                && totalPercentage >= 80;
    }

    private double calculatePercentage(int mathsMarks, int physicsMarks, int chemistryMarks, int englishMarks) {
        int totalMarks = mathsMarks + physicsMarks + chemistryMarks + englishMarks;
        return (double) totalMarks / 4;
    }
}
