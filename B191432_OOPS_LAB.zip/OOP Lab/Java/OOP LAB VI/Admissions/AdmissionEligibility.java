package Admissions;

public interface AdmissionEligibility {
    boolean checkEligibility(int mathsMarks, int physicsMarks, int chemistryMarks, int englishMarks);
}
