
/*Write a Java program to create package called dept. include a interface with 
methods display_subjects() and create four classes as CSE, ECE, ME and CE that 
implements the interface to display their respective dept‟s subjects lists. Import the 
package to display the subjects list dept wise.
 */
import Departments.*;

public class DepartmentSubjects {
    public static void main(String args[]) {
        CSE cse = new CSE();
        System.out.println("\nSubjects in Computer Science Engineering: \n");
        cse.displaySubjects();
        System.out.println("\nSubjects in Electrical and Electronics Engineering: \n");
        ECE ece = new ECE();
        ece.displaySubjects();
    }
}
