/*
 Create a package admission and include interfaces and classes and import them 
to design a system for engineering admissions.
Admission to an Engineering college is given if the following conditions are 
Satisfied
 (i) Maths marks >= 90
 (ii) Physics marks >= 95
 (iii) Chemistry marks >= 70
 (iv) English marks >= 80
 (v) Total percentage in all Four subjects >= 80
 
given the marks in Four subjects, implement a program to process the applications
to list the eligible students.
 */

import Admissions.EngineeringAdmission;

public class Admission {
    public static void main(String[] args) {
        EngineeringAdmission admissionProcessor = new EngineeringAdmission();

        // Example students with marks
        int student1Maths = 92;
        int student1Physics = 96;
        int student1Chemistry = 75;
        int student1English = 85;

        int student2Maths = 88;
        int student2Physics = 97;
        int student2Chemistry = 72;
        int student2English = 82;

        // Check eligibility for each student
        boolean isStudent1Eligible = admissionProcessor.checkEligibility(student1Maths, student1Physics,
                student1Chemistry, student1English);
        boolean isStudent2Eligible = admissionProcessor.checkEligibility(student2Maths, student2Physics,
                student2Chemistry, student2English);

        // List eligible students
        if (isStudent1Eligible) {
            System.out.println("Student 1 is eligible for engineering admission.");
        } else {
            System.out.println("Student 1 is not eligible for engineering admission.");
        }

        if (isStudent2Eligible) {
            System.out.println("Student 2 is eligible for engineering admission.");
        } else {
            System.out.println("Student 2 is not eligible for engineering admission.");
        }
    }
}
