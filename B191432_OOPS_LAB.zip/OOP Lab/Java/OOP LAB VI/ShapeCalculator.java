/*
Implement the following 
a. Create a package named shapes.
b. Create classes in the package representing common geometric shapes such as 
Square, Triangle, and Circle. The classes should contain the area and 
perimeter methods in them.
c. Compile the package.
d. Use this package (import the package) to find area and perimeter of different 
shapes as chosen by the user.
*/

import Shape.*;

import java.util.Scanner;

public class ShapeCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking user input for shape type and dimensions
        System.out.println("Choose a shape (1. Square, 2. Triangle, 3. Circle):");
        int choice = scanner.nextInt();

        Shapes shape;

        switch (choice) {
            case 1:
                System.out.println("Enter the side length of the square:");
                double side = scanner.nextDouble();
                shape = new Square(side);
                break;
            case 2:
                System.out.println("Enter the three sides of the triangle:");
                double side1 = scanner.nextDouble();
                double side2 = scanner.nextDouble();
                double side3 = scanner.nextDouble();
                shape = new Triangle(side1, side2, side3);
                break;
            case 3:
                System.out.println("Enter the radius of the circle:");
                double radius = scanner.nextDouble();
                shape = new Circle(radius);
                break;
            default:
                System.out.println("Invalid choice");
                break;
        }

        // Displaying area and perimeter
        System.out.println("Area: " + shape.calculateArea());
        System.out.println("Perimeter: " + shape.calculatePerimeter());
        scanner.close();
    }
}