package Arith;

public class Calculate {
    int ip, rp;

    public Calculate() {
        ip = 0;
        rp = 0;
    }

    public Calculate(int ip, int rp) {
        this.ip = ip;
        this.rp = rp;
    }

    public void add(int i1, int i2, int j1, int j2) {
        ip = i1 + j1;
        rp = i2 + j2;
        System.out.println("\nAdded value = " + ip + "+" + rp + "i");
    }

    public void subtract(int i1, int i2, int j1, int j2) {
        ip = i1 - j1;
        rp = i2 - j2;
        System.out.println("Subtracted value = " + ip + "-" + rp + "i\n");
    }
}
