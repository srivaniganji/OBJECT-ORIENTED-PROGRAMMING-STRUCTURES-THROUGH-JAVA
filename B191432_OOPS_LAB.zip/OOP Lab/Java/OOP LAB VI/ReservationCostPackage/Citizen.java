package ReservationCostPackage;

public class Citizen extends Passenger {

}
