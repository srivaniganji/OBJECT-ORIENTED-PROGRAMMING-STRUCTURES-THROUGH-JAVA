package ReservationCostPackage;

public class SeniorCitizen extends Passenger {

}
