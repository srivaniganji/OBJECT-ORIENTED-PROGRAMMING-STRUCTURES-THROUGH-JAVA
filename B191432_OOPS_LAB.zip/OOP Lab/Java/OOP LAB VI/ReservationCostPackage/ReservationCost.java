package ReservationCostPackage;

public interface ReservationCost {
    double total_fare(Passenger[] passengers);
}
