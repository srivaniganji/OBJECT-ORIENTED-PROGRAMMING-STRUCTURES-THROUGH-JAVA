package ReservationCostPackage;

public abstract class Passenger {
    // Any common properties or methods for passengers can be added here
}
