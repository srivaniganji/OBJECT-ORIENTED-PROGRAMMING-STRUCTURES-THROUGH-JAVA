package ReservationCostPackage;

public class Child extends Passenger {

}
