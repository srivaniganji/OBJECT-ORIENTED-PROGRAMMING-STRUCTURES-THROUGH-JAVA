package Departments;

public interface Department {
    void displaySubjects();
}