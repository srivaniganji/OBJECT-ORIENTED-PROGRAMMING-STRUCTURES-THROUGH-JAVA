/*
Implement the following 
a. Create the package sounds.
b. Create interface dolby( with abstract method playDolby), and class Podcast( 
with method playPodcast) in the package.
c. compile the package.
d. Use the package(import the package) to play sounds as chosen by the user.
Note : the methods should include the text as “play XXXXsound”. 
*/

import Sounds.*;

public class PlaySounds {
    public static void main(String args[]) {
        PodCast s = new PodCast();
        s.playDolby();
        s.playPodcast();
    }
}
