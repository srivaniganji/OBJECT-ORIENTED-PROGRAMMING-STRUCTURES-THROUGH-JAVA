
/*
Create a package M-Seva and include the interfaces and classes for the 
following case study and import the package to identify the disease as per user 
inputs.
Model a M-Seva (Medical-seva) system, that prompts the user to enter his/her 
symptoms and displays the disease name. 
Model for diseases: Acute pancreatitis (AP), Appendicitis (A), Bladder Cancer 
(BC), Pancreatic Cancer (PC)
Common Symptoms for all diseases: Stomach ache, vomiting, low eye sight
Symptoms for „AP‟ : Muscle ache, fever
Symptoms for „A‟ : fever, fatigue
Symptoms for „BC‟ : skin allergy, low bp
Symptoms for „PC‟ : fever, fatigue
As and when M-Seva is alive it has to display message as “Welcome to M-Seva” 
and prompt the user to enter symptoms. If same symptoms among more than one 
disease then display all those disease names.
*/
import java.util.*;

import MSeva.MedicalCheck;

public class MedicalSeva {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        MedicalCheck m = new MedicalCheck();
        boolean stomachAche = false, vomits = false, eyeSight = false, muscleAche = false, fever = false,
                fatigue = false, skinAllergy = false, lowBp = false;
        char ch;
        System.out.println("Enter Y/y if feel like having..");
        System.out.println("Stomach Ache: ");
        ch = In.nextLine().charAt(0);
        if (ch == 'Y' || ch == 'y')
            stomachAche = true;
        System.out.println("Vomits: ");
        ch = In.nextLine().charAt(0);
        if (ch == 'Y' || ch == 'y')
            vomits = true;
        System.out.println("Low Eye Sight: ");
        ch = In.nextLine().charAt(0);
        if (ch == 'Y' || ch == 'y')
            eyeSight = true;
        System.out.println("Muscle Ache: ");
        ch = In.nextLine().charAt(0);
        if (ch == 'Y' || ch == 'y')
            muscleAche = true;
        System.out.println("Fever: ");
        ch = In.nextLine().charAt(0);
        if (ch == 'Y' || ch == 'y')
            fever = true;
        System.out.println("Fatigue: ");
        ch = In.nextLine().charAt(0);
        if (ch == 'Y' || ch == 'y')
            fatigue = true;
        System.out.println("Skin Allergy: ");
        ch = In.nextLine().charAt(0);
        if (ch == 'Y' || ch == 'y')
            skinAllergy = true;
        System.out.println("Low BP: ");
        ch = In.nextLine().charAt(0);
        if (ch == 'Y' || ch == 'y')
            lowBp = true;
        m.checkDisease(stomachAche, vomits, eyeSight, muscleAche, fever, fatigue, skinAllergy, lowBp);
        In.close();
    }
}
