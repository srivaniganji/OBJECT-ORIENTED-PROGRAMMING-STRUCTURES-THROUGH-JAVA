package MSeva;

/*Create a package M-Seva and include the interfaces and classes for the 
following case study and import the package to identify the disease as per user 
inputs.
Model a M-Seva (Medical-seva) system, that prompts the user to enter his/her 
symptoms and displays the disease name. 
Model for diseases: Acute pancreatitis (AP), Appendicitis (A), Bladder Cancer 
(BC), Pancreatic Cancer (PC)
Common Symptoms for all diseases: Stomach ache, vomiting, low eye sight
Symptoms for „AP‟ : Muscle ache, fever
Symptoms for „A‟ : fever, fatigue
Symptoms for „BC‟ : skin allergy, low bp
Symptoms for „PC‟ : fever, fatigue
As and when M-Seva is alive it has to display message as “Welcome to M-Seva” 
and prompt the user to enter symptoms. If same symptoms among more than one 
disease then display all those disease names. */

public class MedicalCheck {
    // boolean stomachAche, vomits, eyeSight, muscleAche, fever, fatigue,
    // skinAllergy, lowBp;

    public MedicalCheck() {
        System.out.println("Welcome to M-Seva!");
    }

    public void checkDisease(boolean stomachAche, boolean vomits, boolean eyeSight, boolean muscleAche, boolean fever,
            boolean fatigue, boolean skinAllergy, boolean lowBp) {
        System.out.print("You are suffering from ");
        if (stomachAche && vomits && eyeSight && muscleAche && fever)
            System.out.println("Acute Pacreatitis (AP)");
        if (stomachAche && vomits && eyeSight && fever && fatigue)
            System.out.println("Appendicitis (A)");
        if (stomachAche && vomits && eyeSight && skinAllergy && lowBp)
            System.out.println("Bladder Cancer (BC)");
        if (stomachAche && vomits && eyeSight && fever && fatigue)
            System.out.println("Pancreatic Cancer (PC)");
        else
            System.out.print("You are safe..");
        System.out.println("Take Care and Thank you!");
    }
}
