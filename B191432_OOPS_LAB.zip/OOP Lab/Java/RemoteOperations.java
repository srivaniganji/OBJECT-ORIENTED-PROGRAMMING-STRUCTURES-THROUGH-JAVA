package TVRemote;

public class RemoteOperations implements Remote {
	boolean isOn = false;

	public void switchOn() {
		if(!isOn) {
			isOn = true;
			System.out.println("TV Switched ON!"); 
		}
	}

	public void switchOff() {
		if(isOn) {
			isOn = false;
			System.out.println("TV Switched OFF!"); 
		}
	}
	
	public void setChannel(int ch) {
		if(isOn) {
			switch(ch) {
				case 1: 
					System.out.println("Channel 1");
					break;

				case 2:
					System.out.println("Channel 2");
					break;

				case 3: 
					System.out.println("Channel 3");
					break;

				case 4: 
					System.out.println("Channel 4");
					break;

				default:
					System.out.println("Invalid channel number.");
			}
		}
		else 
			System.out.println("Please turn ON the TV!");
	}
}