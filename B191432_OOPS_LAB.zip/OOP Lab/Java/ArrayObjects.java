class Student {
    int roll;
    String name;
    int marks;
}

public class ArrayObjects {
    public static void main(String args[]) {
        Student s1 = new Student();
        s1.roll = 1;
        s1.name = "Srivani";
        s1.marks = 100;

        Student s2 = new Student();
        s2.roll = 2;
        s2.name = "rtyuui";
        s2.marks = 89;

        Student s3 = new Student();
        s3.roll = 3;
        s3.name = "fgdhsj";
        s3.marks = 57;

        Student s[] = new Student[3];
        s[0] = s1;
        s[1] = s2;
        s[2] = s3;

        for (int i = 0; i < s.length; i++) {
            System.out.println(s[i].roll + ". " + s[i].name + " : " + s[i].marks);
        }
    }
}
