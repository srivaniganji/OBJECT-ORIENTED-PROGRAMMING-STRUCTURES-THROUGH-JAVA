//GCD of given two numbers;

import java.util.*;

public class GCD {

    public static int calculateGCD(int a, int b) {
        int gcd = Math.min(a, b);
        while (gcd > 0) {
            if (a % gcd == 0 && b % gcd == 0)
                break;
            gcd--;
        }
        return gcd;
    }

    public static int calculateGCDrec(int a, int b) {
        if (a == b)
            return a;
        else if (a > b)
            return calculateGCDrec(a - b, b);
        else
            return calculateGCDrec(a, b - a);
    }

    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.print("Enter a: ");
        int a = In.nextInt();
        System.out.print("Enter b: ");
        int b = In.nextInt();
        System.out.println("GCD of given number = " + calculateGCD(a, b));
        In.close();
    }
}
