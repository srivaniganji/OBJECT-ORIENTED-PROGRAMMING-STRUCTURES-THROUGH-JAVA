
/*
 * Write a Program using Threads  for the following case study: Movie Theatre    
 * To watch a movie the following process is to be followed, at first get the ticket then show     
 * the ticket. Assume that N persons are trying to enter the Theatre hall all at once, display     
 * their sequence of entry into theater.
 * Note: The person should enter only after getting a ticket and showing it to the boy.
 */

import java.util.*;

class MyThread extends Thread {

    public void run() {
        Scanner In = new Scanner(System.in);
        int n;
        System.out.println("Enter number of persons in the queue: ");
        n = In.nextInt();
        for (int i = 1; i <= n; i++) {
            try {
                System.out.println("Person " + i + " got the ticket.");
                System.out.println("Person " + i + " entered the hall.");
                Thread.sleep(100);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        In.close();
    }
}

public class Theatre {
    public static void main(String args[]) {
        MyThread thread = new MyThread();

        Thread t = new Thread(thread);

        t.run();
    }
}
