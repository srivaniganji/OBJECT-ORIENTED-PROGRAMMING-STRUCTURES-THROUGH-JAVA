/*
   Write a program to create MyThread class with run() method and then attach a thread to
   this MyThread class object.
 */

class MyThread extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            try {
                System.out.println("Thread " + i + " running..");
                Thread.sleep(10);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }
}

public class MyThread1 {
    public static void main(String args[]) {
        MyThread thread = new MyThread();
        Thread t = new Thread(thread);
        t.run();
    }
}
