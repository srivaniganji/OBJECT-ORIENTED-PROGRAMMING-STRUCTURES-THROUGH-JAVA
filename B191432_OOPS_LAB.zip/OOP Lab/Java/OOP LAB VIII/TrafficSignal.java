
/*
 * Write a Program using Threads  to simulate a traffic light. The Signal lights should  glow
 * after each 10 second, one by one. For example: Firstly Red, then after 10 seconds, red    
 * will be put to off and yellow will start glowing and then accordingly green. 
 */

class MyThread extends Thread {
    String s;

    public MyThread(String s) {
        this.s = s;
    }

    public void run() {
        try {
            System.out.println(s + " light ON");
            Thread.sleep(100);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}

public class TrafficSignal {
    public static void main(String args[]) {
        MyThread Red = new MyThread("Red");
        MyThread Yellow = new MyThread("Yellow");
        MyThread Green = new MyThread("Green");

        Thread t1 = new Thread(Red);
        Thread t2 = new Thread(Yellow);
        Thread t3 = new Thread(Green);

        t1.start();
        t2.start();
        t3.start();
    }
}
