//Calculate the Factorial of the given number;

import java.util.*;

public class Factorial {
    public static int calculateFactorial(int n) {
        int fact = 1;
        while (n > 1) {
            fact = fact * n;
            n--;
        }
        return fact;
    }

    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int n = In.nextInt();
        System.out.println("Factorial of given number = " + calculateFactorial(n));
        In.close();
    }
}
