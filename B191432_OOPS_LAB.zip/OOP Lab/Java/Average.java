//Calculate average of 3 numbers given by the User;

import java.util.*;

public class Average {
    public static double calculateAverage(int a, int b, int c) {
        return (a + b + c) / 3.0;
    }

    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.print("Enter first number: ");
        int a = In.nextInt();
        System.out.print("Enter second number: ");
        int b = In.nextInt();
        System.out.print("Enter third number: ");
        int c = In.nextInt();
        System.out.println("Average = " + calculateAverage(a, b, c));
        In.close();
    }
}
