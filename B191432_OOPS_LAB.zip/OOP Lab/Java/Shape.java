/*Find the area perimeter of square circle rectangle using methods getArea() and getperimeter(). */

class Shapes {

}

class Square extends Shapes {
    int getArea(int side) {
        return side * side;
    }

    int getPerimeter(int side) {
        return 4 * side;
    }
}

class Rectangle extends Shapes {
    int getArea(int length, int breadth) {
        return length * breadth;
    }

    int getPerimeter(int length, int breadth) {
        return 2 * (length + breadth);
    }
}

class Circle extends Shapes {

    double getArea(int radius) {
        return Math.PI * radius * radius;
    }

    double getPerimeter(int radius) {
        return Math.PI * 2 * radius;
    }
}

public class Shape {
    public static void main(String args[]) {
        Rectangle s = new Rectangle();
        System.out.println("--Rectangle--");
        System.out.println("Area = " + s.getArea(5, 10));
        System.out.println("Perimeter = " + s.getPerimeter(5, 10));
        Circle c = new Circle();
        System.out.println("--Circle--");
        System.out.println("Area = " + c.getArea(5));
        System.out.println("Perimeter = " + c.getPerimeter(5));
        Square r = new Square();
        System.out.println("--Square--");
        System.out.println("Area = " + r.getArea(5));
        System.out.println("Perimeter = " + r.getPerimeter(5));
    }
}
