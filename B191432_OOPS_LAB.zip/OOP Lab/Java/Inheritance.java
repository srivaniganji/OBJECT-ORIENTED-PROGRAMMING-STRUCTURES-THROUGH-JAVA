/*
 * Example - 1
 * 
 * class Shape {
 * String color = "White";
 * 
 * void print() {
 * System.out.println("Shape Class!");
 * }
 * }
 * 
 * class Triangle extends Shape {
 * void print() {
 * System.out.println("Triangle Class!");
 * }
 * }
 * 
 * class EquilateralTriangle extends Triangle {
 * void print() {
 * System.out.println("Equilateral Triangle Class!");
 * }
 * 
 * void printColor() {
 * System.out.println(color);
 * }
 * }
 * 
 * class Circle extends Shape {
 * void print() {
 * System.out.println("Circle Class!");
 * }
 * 
 * void printColor() {
 * System.out.println(color);
 * }
 * }
 * 
 * public class Inheritance {
 * public static void main(String args[]) {
 * Shape s = new Shape();
 * s.print();
 * 
 * Triangle t = new Triangle();
 * t.print();
 * 
 * EquilateralTriangle e = new EquilateralTriangle();
 * e.color = "White";
 * e.printColor();
 * e.print();
 * 
 * Circle c = new Circle();
 * c.color = "Blue";
 * c.print();
 * }
 * }
 */

//Example - 2

// Single Level Inheritance
class AdvCalc extends Calc {
    public int multiply(int n1, int n2) {
        return n1 * n2;
    }

    public int divide(int n1, int n2) {
        return n1 / n2;
    }

    public char[] mul(int i, int j) {
        return null;
    }
}

// Multi Level Inheritance
class SciCalc extends AdvCalc {
    public double power(int n1, int n2) {
        return Math.pow(n1, n2);
    }

    // Method Overriding
    @Override
    public int add(int n1, int n2) {
        return n1 + n2 + 1;
    }
}

// Main Class
public class Inheritance {
    public static void main(String args[]) {
        SciCalc C = new SciCalc();
        System.out.println("Addition = " + C.add(2, 3));
        System.out.println("Subtraction = " + C.subtract(7, 2));
        System.out.println("Multiplication = " + C.multiply(2, 3));
        System.out.println("Division = " + C.divide(7, 2));
        System.out.println("Exponent = " + C.power(5, 2));
    }
}
