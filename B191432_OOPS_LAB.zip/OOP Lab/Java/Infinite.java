//Write an Infinite Loop 

public class Infinite {
    public static void main(String args[]) {
        int n = 1;
        do {
            System.out.print(n + " ");
        } while (n > 0);

    }
}
