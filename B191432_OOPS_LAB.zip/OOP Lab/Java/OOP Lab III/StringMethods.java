import java.util.*;

public class StringMethods {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.print("Enter s1: ");
        String s1 = In.nextLine();
        System.out.print("Enter s2: ");
        String s2 = In.nextLine();
        // compareTo
        System.out.println("CompareTo: " + s1.compareTo(s2));
        // equals
        System.out.println("Equals: " + s1.equals(s2));
        // equalsIgnoreCase
        System.out.println("EqualsIgnoreCase: " + s1.equalsIgnoreCase(s2));
        // concat
        System.out.println("Concat: " + s1.concat(s2));
        System.out.println("Concat: " + s2.concat(s1));
        In.close();
    }
}