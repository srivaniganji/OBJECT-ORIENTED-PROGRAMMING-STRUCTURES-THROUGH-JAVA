// Write an application that finds the length of a given string.

import java.util.*;

public class Length {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        String s = In.nextLine();
        s += '\0';
        int i = 0;
        while (s.charAt(i) != '\0') {
            i++;
        }
        System.out.println("Length of String = " + i);
        In.close();
    }
}
