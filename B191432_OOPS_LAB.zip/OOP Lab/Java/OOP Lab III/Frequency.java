//Write an application that uses String method indexOf to determine the total
// number of occurrences of any given alphabet in a defined text.

import java.util.*;

public class Frequency {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        // String s = In.nextLine();
        // char c = In.next().charAt(0);
        String s = new String("Srivani");
        char c = 'i';
        int count = 0;
        int n = s.length();
        int i = s.indexOf(c);
        while (i < n && i != -1) {
            count++;
            i = s.indexOf(c, i + 1);
        }
        System.out.println("Frequency of " + c + " is " + count);
        In.close();
    }
}
