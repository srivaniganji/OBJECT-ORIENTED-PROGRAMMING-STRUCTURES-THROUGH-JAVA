// Write a program to display details of the required employee based on his Id.
// The details of employee includes, Emp_name, Emp_age, Emp_gender, 
// Emp_designation, Emp_salary, Emp_Address etc.,

import java.util.*;

class Employee {
    String id, name, gender, designation, address;
    int age;
    double salary;

    Employee(String id, String name, int age, String gender, String designation, String address, double salary) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.designation = designation;
        this.address = address;
        this.age = age;
        this.salary = salary;
    }
}

public class Employees {
    public static void main(String args[]) {
        Employee[] e = new Employee[4];

        for (int i = 0; i < 4; i++) {

        }
    }
}
