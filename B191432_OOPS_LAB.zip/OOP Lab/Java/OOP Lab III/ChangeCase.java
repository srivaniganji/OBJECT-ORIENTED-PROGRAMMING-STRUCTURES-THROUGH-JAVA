//Write an application that changes any given string with uppercase letters, 
//displays it, changes it back to lowercase letters and displays it.

import java.util.*;

public class ChangeCase {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.print("Enter String: ");
        String s = In.nextLine();
        System.out.println("Entered String: " + s);
        System.out.println("UpperCase: " + s.toUpperCase());
        System.out.println("LowerCase: " + s.toLowerCase());
        In.close();
    }
}
