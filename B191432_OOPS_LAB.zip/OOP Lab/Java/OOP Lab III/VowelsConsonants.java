// Write a Java program to print all vowels in given string and count number of 
// vowels and consonants present in given string

import java.util.*;

public class VowelsConsonants {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.print("Enter text: ");
        String text = In.next();
        int vowels = 0;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == 'a' || text.charAt(i) == 'e' || text.charAt(i) == 'i' || text.charAt(i) == 'o'
                    || text.charAt(i) == 'u' || text.charAt(i) == 'A' || text.charAt(i) == 'E' || text.charAt(i) == 'I'
                    || text.charAt(i) == 'O' || text.charAt(i) == 'U')
                vowels++;
        }
        int consonants = text.length() - vowels;
        System.out.println("Vowels = " + vowels);
        System.out.println("Consonants =" + consonants);
        In.close();
    }
}
