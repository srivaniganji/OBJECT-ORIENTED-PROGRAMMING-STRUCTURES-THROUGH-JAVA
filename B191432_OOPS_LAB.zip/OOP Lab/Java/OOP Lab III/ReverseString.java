// Write an application that uses String method charAt to reverse the string.

import java.util.*;

public class ReverseString {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        String s = In.next();
        int n = s.length();
        String rev = "";
        for (int i = 0; i < n; i++)
            rev = s.charAt(i) + rev;
        System.out.println("Reverse of String = " + rev);
        In.close();
    }
}
