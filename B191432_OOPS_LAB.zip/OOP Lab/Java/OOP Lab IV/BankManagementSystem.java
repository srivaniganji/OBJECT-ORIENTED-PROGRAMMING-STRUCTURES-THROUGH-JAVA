/* Case study : Bank Management System
SBI Bank had two branches Basar and Nizambad each with 5 customers, uniquely identified by 
their Branch_name and Acct_No. Implement an application that prompts account holders to 
enter user name(Branch_name) and password(Acct_No), on successful authorization they can 
perform following transactions, after every exit( ) , the application should ask for 
Exit_application(Yes/No), on Yes exit from application on No prompt for New user credentials. 
Create a class Account with an instance variable balance (double). It should contain a
constructor that initializes the balance, ensure that the initial balance is
greater than 1000.0
Account details : Bank_Name, Branch_Name, Acct_Name, Acct_No, Acct_Bal, 
Acct_Address.
Create four methods namely credit( ), debit( ), getBalance( ) and exit().
The credit( ) adds the amount (passed as parameter) to balance and does not return any
data. debit( ) withdraws money from an Account, getBalance displays the
amount, exit() exits from the individual Transaction.
Note :
Ensure that the debit amount does not exceed the Account’s balance, in that case the
balance should be left unchanged and the method should print an alert message as
“Debit amount exceeded account balance” */

import java.util.Scanner;

class Account {
    private double balance;

    // Constructor to initialize the balance with a minimum value
    public Account(double initialBalance) {
        if (initialBalance > 1000.0) {
            this.balance = initialBalance;
        } else {
            System.out.println("Initial balance should be greater than 1000.0");
        }
    }

    // Method to credit (add) an amount to the balance
    public void credit(double amount) {
        this.balance += amount;
        System.out.println("Amount credited successfully. New balance: " + this.balance);
    }

    // Method to debit (withdraw) an amount from the balance
    public void debit(double amount) {
        if (amount <= this.balance) {
            this.balance -= amount;
            System.out.println("Amount debited successfully. New balance: " + this.balance);
        } else {
            System.out.println("Debit amount exceeded account balance. Transaction canceled.");
        }
    }

    // Method to get the current balance
    public double getBalance() {
        return this.balance;
    }
}

public class BankManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Bank Name: ");
        String bankName = scanner.nextLine();

        // Assuming two branches "Basar" and "Nizamabad" for SBI Bank
        System.out.print("Enter Branch Name (Basar/Nizamabad): ");
        String branchName = scanner.nextLine();

        System.out.print("Enter Account Holder Name: ");
        String accountName = scanner.nextLine();

        System.out.print("Enter Account Number: ");
        String accountNumber = scanner.nextLine();

        System.out.print("Enter Initial Account Balance (greater than 1000.0): ");
        double initialBalance = scanner.nextDouble();

        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter Account Address: ");
        String accountAddress = scanner.nextLine();

        // Create an Account object with the provided details
        Account account = new Account(initialBalance);

        char exitChoice;
        do {
            // Display menu
            System.out.println("\nChoose an option:");
            System.out.println("1. Credit");
            System.out.println("2. Debit");
            System.out.println("3. Get Balance");
            System.out.println("4. Exit");

            int option = scanner.nextInt();

            switch (option) {
                case 1:
                    System.out.print("Enter amount to credit: ");
                    double creditAmount = scanner.nextDouble();
                    account.credit(creditAmount);
                    break;

                case 2:
                    System.out.print("Enter amount to debit: ");
                    double debitAmount = scanner.nextDouble();
                    account.debit(debitAmount);
                    break;

                case 3:
                    System.out.println("Current Balance: " + account.getBalance());
                    break;

                case 4:
                    System.out.print("Exit application? (Y/N): ");
                    exitChoice = scanner.next().charAt(0);
                    if (exitChoice == 'Y' || exitChoice == 'y') {
                        System.out.println("Exiting application. Thank you!");
                        System.exit(0);
                    }
                    break;

                default:
                    System.out.println("Invalid option. Please choose a valid option.");
            }

            System.out.print("Exit from the current transaction? (Y/N): ");
            exitChoice = scanner.next().charAt(0);

        } while (!(exitChoice == 'Y' || exitChoice == 'y'));

        System.out.println("Enter new user credentials for the next transaction.");

        scanner.close();
    }
}
