
/*.Suppose that we are required to model students and teachers in our application. We can define 
a superclass called Person to store common properties such as name and address, and subclasses 
Student and Teacher for their specific properties. For students, we need to maintain the courses 
taken and their respective grades; add a course with grade, print all courses taken and the 
average grade. Assume that a student takes no more than 30 courses for the entire program. For 
teachers, we need to maintain the courses taught currently, and able to add or remove a course 
taught. Assume that a teacher teaches not more than 5 courses concurrently. */
import java.util.*;

class Person {
    String name;
    String address;

    Person(String name, String address) {
        this.name = name;
        this.address = address;
    }

    String getname() {
        return name;
    }

    String getAddress() {
        return address;
    }

    void setAddress(String address) {
        this.address = address;
    }

    void setName(String name) {
        this.name = name;
    }
}

class Student extends Person {

    Student(String name, String address) {
        super(name, address);
    }

    int numCourses = 0;
    ArrayList<String> courses = new ArrayList<>();
    ArrayList<Integer> grades = new ArrayList<>();
    // String[] courses = {};
    // int[] grades = {};

    void addCourseGrade(String course, int grade) {
        boolean flag = false;
        for (int i = 0; i < numCourses; i++) {
            if (courses.get(i) == course) {
                flag = true;
                break;
            }
        }
        if (flag == true)
            System.out.println("Course already taken!");
        // return !flag;
        courses.add(course);
        grades.add(grade);
        numCourses = courses.size();
        // return !flag;
        System.out.println("Course added to the Student Successfully!");
    }

    void removeCourse(String course) {
        boolean flag = false;
        int i;
        for (i = 0; i < numCourses; i++) {
            if (courses.get(i) == course) {
                flag = true;
                break;
            }
        }
        if (flag == false) {
            System.out.println("Mentioned course was not taken by the Student!");
            return;
        }
        courses.remove(i);
        grades.remove(i);
        numCourses--;
        System.out.println("Course removed from Students!");
    }

    void printGrades() {
        System.out.println("Course - Grade");
        for (int i = 0; i < numCourses; i++) {
            System.out.println(courses.get(i) + " - " + grades.get(i));
        }
    }

    double getAverageGrade() {
        int sum = 0;
        for (int i = 0; i < numCourses; i++) {
            sum += grades.get(i);
        }
        return (double) sum / numCourses;
    }

    void print() {
        System.out.println("\n--Student Details--");
        System.out.println("Student name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Courses taken: " + courses);
        System.out.println("Grades: " + grades);
        System.out.println("Average grade: " + getAverageGrade());
        System.out.println("");
    }
}

class Teacher extends Person {

    Teacher(String name, String address) {
        super(name, address);
    }

    int numCourses = 0;
    ArrayList<String> courses = new ArrayList<>();
    // String[] courses = {};

    void addCourse(String course) {
        boolean flag = false;
        for (int i = 0; i < numCourses; i++) {
            if (courses.get(i) == course) {
                flag = true;
                break;
            }
        }
        if (flag == true)
            System.out.println("Course already exists!");
        // return !flag;
        courses.add(course);
        numCourses = courses.size();
        // return !flag;
        System.out.println("Course added to Teacher Successfully!");
    }

    void removeCourse(String course) {
        boolean flag = false;
        int i;
        for (i = 0; i < numCourses; i++) {
            if (courses.get(i) == course) {
                flag = true;
                break;
            }
        }
        if (flag == false) {
            System.out.println("Mentioned course was not taken by Teacher!");
            return;
        }
        courses.remove(i);
        numCourses--;
        System.out.println("Course removed from Teacher!");
    }

    /*
     * boolean removeCourse(String course) {
     * if(courses.find(course)==-1)
     * return false;
     * }
     */

    void print() {
        System.out.println("\n--Teacher Details--");
        System.out.println("Teacher name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Courses teaching: " + courses);
        System.out.println("");
    }
}

public class StudentTeacher {
    public static void main(String args[]) {
        Student s = new Student("John", "US");
        s.print();
        s.addCourseGrade("DSA", 10);
        s.addCourseGrade("OS", 9);

        Teacher t = new Teacher("Alice", "Australia");
        t.print();
        t.addCourse("DAA");
        t.addCourse("Maths");

        s.print();
        t.print();

        s.removeCourse("OS");
        t.removeCourse("OS");

        s.print();
        t.print();
    }
}
