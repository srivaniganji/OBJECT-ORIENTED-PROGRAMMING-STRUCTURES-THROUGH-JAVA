/*New year welcomes with a Grand sale from topmost E-commerce sites Amazon and Flipkart.
Design an application that prompts user to enter product name, company it belongs to and the 
quantity(Note : you can input more if your application requires) and suggest him/her(cost 
effective) where to buy the product either from Amazon or E-commerce. 
Amazon offers 10% Discount for HDFC credit card holders and 15% discount on purchase
above 50,000.
Flipkart offers 30% Discount if he/she is a RGUKT student and 5% discount on purchase above 
30,000. */

import java.util.*;

class eCommerce {
    String product, cardType;
    int quantity;
    float cost;

    eCommerce(String product, int quantity, float cost, String cardType) {
        this.product = product;
        this.quantity = quantity;
        this.cost = cost;
        this.cardType = cardType;
    }
}

class Amazon extends eCommerce {
    // float aCost;

    Amazon(String product, int quantity, float aCost, String cardType) {
        super(product, quantity, aCost, cardType);
    }

    float getTotalCost() {
        float total = quantity * cost;
        if (total > 50000)
            total = total - (15 * total) / 100;
        else if (cardType == "HDFC")
            total = total - (10 * total) / 100;
        return total;
    }
}

class Flipkart extends eCommerce {
    // float fCost;

    Flipkart(String product, int quantity, float fCost, String cardType) {
        super(product, quantity, fCost, cardType);
    }

    float getTotalCost() {
        float total = quantity * cost;
        if (cardType == "RGUKT")
            total = total - (30 * total) / 100;
        else if (total > 30000)
            total = total - (5 * total) / 100;
        return total;
    }
}

public class OnlineShopping {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.println("Enter product name: ");
        String product = In.next();
        System.out.println("Enter quantity: ");
        int quantity = In.nextInt();
        System.out.println("Enter cost at Amazon: ");
        float aCost = In.nextFloat();
        System.out.println("Ente cost at Flipkart: ");
        float fCost = In.nextFloat();
        System.out.println("Enter card type: ");
        String cardType = In.next();

        Amazon a = new Amazon(product, quantity, aCost, cardType);
        Flipkart f = new Flipkart(product, quantity, fCost, cardType);

        float aTotal = a.getTotalCost();
        float fTotal = f.getTotalCost();

        System.out.println("Total cost at Amazon after discount = " + aTotal);
        System.out.println("Total cost at Flipkart after discount = " + fTotal);

        if (aTotal < fTotal)
            System.out.println("Buy at Amazon!");
        else
            System.out.println("Buy at Flipkart!");

        In.close();
    }
}
