
// Write an application that prompts the user for required inputs to find the area and perimeter 
// of Circle, Square, Rectangle using methods getArea( ) and getPerimeter( ).
import java.util.*;

abstract class Shape {
    Scanner In = new Scanner(System.in);

    abstract double getArea();

    abstract double getPerimeter();
}

class Circle extends Shape {
    int radius;

    Circle() {
        System.out.println("--Circle--");
        System.out.print("Enter radius: ");
        radius = In.nextInt();
    }

    double getArea() {
        return Math.PI * radius * radius;
    }

    double getPerimeter() {
        return 2 * Math.PI * radius;
    }
}

class Square extends Shape {

    int side;

    Square() {
        System.out.println("--Square--");
        System.out.print("Enter side: ");
        side = In.nextInt();
    }

    double getArea() {
        return side * side;
    }

    double getPerimeter() {
        return 4 * side;
    }
}

class Rectangle extends Shape {
    int length, breadth;

    Rectangle() {
        System.out.println("--Rectangle--");
        System.out.print("Enter length: ");
        length = In.nextInt();
        System.out.print("Enter breadth: ");
        breadth = In.nextInt();
    }

    double getArea() {
        return length * breadth;
    }

    double getPerimeter() {
        return 2 * (length + breadth);
    }
}

public class Shapes {
    public static void main(String args[]) {
        Circle c = new Circle();
        System.out.println("Area = " + c.getArea());
        System.out.println("Perimeter = " + c.getPerimeter());

        Square s = new Square();
        System.out.println("Area = " + s.getArea());
        System.out.println("Perimeter = " + s.getPerimeter());

        Rectangle r = new Rectangle();
        System.out.println("Area = " + r.getArea());
        System.out.println("Perimeter = " + r.getPerimeter());
    }
}
