/*In following game app, we have many types of monsters that can attack. We shall design a 
superclass called Monster and define the method attack() in the superclass. The subclasses shall 
then provides their actual implementation. In the main program, we declare instances of 
superclass, substituted with actual subclass (Up casting); and invoke method defined in the 
superclass.
 */

abstract class Monster {
    String name;

    abstract String attack();
}

class FireMonster extends Monster {
    String attack() {
        return "FireMonster attacks!";
    }
}

class WaterMonster extends Monster {
    String attack() {
        return "WaterMonster attacks!";
    }
}

class StoneMonster extends Monster {
    String attack() {
        return "StoneMonster attacks!";
    }
}

public class Monsters {
    public static void main(String args[]) {
        Monster fm = new FireMonster();
        System.out.println(fm.attack());

        Monster wm = new WaterMonster();
        System.out.println(wm.attack());

        Monster sm = new StoneMonster();
        System.out.println(sm.attack());
    }
}
