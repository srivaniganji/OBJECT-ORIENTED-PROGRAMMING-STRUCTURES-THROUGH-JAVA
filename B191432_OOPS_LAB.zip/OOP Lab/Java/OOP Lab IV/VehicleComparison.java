/*RGUKT planned to provide vehicles (2 and 4 wheelers) to all class CR’s, and requested the 
company name and model of 2 and 4 wheelers from CR’s. As Indian market has lot of models 
in 2 wheelers and 4 wheelers, Mr. Ramesh is in dilemma to choose the best model among all 2 
wheelers and 4 wheelers. 
Write an application which compares the best model among 2 wheelers and 4 wheelers. 
Create a super class Vehicle, derive the sub-classes TwoWheeler and FourWheeler .
Two wheeler can have properties such as Company, Model, Mileage, Fuel Capacity, 
Displacement, Front Brake, Rear Brake, Tyre Type, Head lamp, User Reviews
Four wheeler can have properties such as Company, Model, Mileage, Fuel Capacity, 
Displacement, Air Conditioner, air bags, Power Steering, Rain Sensing Wiper.
Maintain atleast four 2-wheelers and Four 4-wheelers details in repository.
Application usage : Display all companies and models of 2 and 4 wheelers available in 
repository. User can choose any number of vehicles to compare, compare among them and 
display the Company and model of the vehicle to buy. If user opted for 2 wheeler, compare only 
2 wheeler vehicles and same with 4 wheeler. */

import java.util.ArrayList;
import java.util.Scanner;

class Vehicle {
    String company;
    String model;
    float mileage;
    float fuelCapacity;
    float displacement;

    // Constructor
    public Vehicle(String company, String model, float mileage, float fuelCapacity, float displacement) {
        this.company = company;
        this.model = model;
        this.mileage = mileage;
        this.fuelCapacity = fuelCapacity;
        this.displacement = displacement;
    }

    // Display details
    public void displayDetails() {
        System.out.println("Company: " + company + ", Model: " + model);
        System.out.println("Mileage: " + mileage + " km/l, Fuel Capacity: " + fuelCapacity + " liters, Displacement: "
                + displacement + " cc");
    }
}

class TwoWheeler extends Vehicle {
    String frontBrake;
    String rearBrake;
    String tyreType;
    String headLamp;
    String userReviews;

    // Constructor
    public TwoWheeler(String company, String model, float mileage, float fuelCapacity, float displacement,
            String frontBrake, String rearBrake, String tyreType, String headLamp, String userReviews) {
        super(company, model, mileage, fuelCapacity, displacement);
        this.frontBrake = frontBrake;
        this.rearBrake = rearBrake;
        this.tyreType = tyreType;
        this.headLamp = headLamp;
        this.userReviews = userReviews;
    }

    // Display details
    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Front Brake: " + frontBrake + ", Rear Brake: " + rearBrake);
        System.out.println("Tyre Type: " + tyreType + ", Head Lamp: " + headLamp + ", User Reviews: " + userReviews);
    }
}

class FourWheeler extends Vehicle {
    boolean airConditioner;
    boolean airBags;
    boolean powerSteering;
    boolean rainSensingWiper;

    // Constructor
    public FourWheeler(String company, String model, float mileage, float fuelCapacity, float displacement,
            boolean airConditioner, boolean airBags, boolean powerSteering, boolean rainSensingWiper) {
        super(company, model, mileage, fuelCapacity, displacement);
        this.airConditioner = airConditioner;
        this.airBags = airBags;
        this.powerSteering = powerSteering;
        this.rainSensingWiper = rainSensingWiper;
    }

    // Display details
    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println(
                "Air Conditioner: " + (airConditioner ? "Yes" : "No") + ", Air Bags: " + (airBags ? "Yes" : "No"));
        System.out.println("Power Steering: " + (powerSteering ? "Yes" : "No") + ", Rain Sensing Wiper: "
                + (rainSensingWiper ? "Yes" : "No"));
    }
}

public class VehicleComparison {
    public static void main(String[] args) {
        // Repository of vehicles
        ArrayList<TwoWheeler> twoWheelers = new ArrayList<>();
        twoWheelers.add(new TwoWheeler("Honda", "CBR250R", 30.0f, 14.5f, 249.6f, "Disc", "Disc", "Tubeless", "LED",
                "Positive user reviews"));
        twoWheelers.add(new TwoWheeler("Yamaha", "YZF R15", 35.0f, 12.0f, 155.1f, "Disc", "Disc", "Tubeless", "LED",
                "Highly rated by users"));

        ArrayList<FourWheeler> fourWheelers = new ArrayList<>();
        fourWheelers.add(new FourWheeler("Toyota", "Innova Crysta", 12.8f, 55.0f, 2694f, true, true, true, true));
        fourWheelers.add(new FourWheeler("Maruti Suzuki", "Baleno", 21.4f, 37.0f, 1197f, true, true, true, false));

        // Display available vehicles
        System.out.println("Available Two Wheelers:");
        for (TwoWheeler bike : twoWheelers) {
            bike.displayDetails();
            System.out.println();
        }

        System.out.println("\nAvailable Four Wheelers:");
        for (FourWheeler car : fourWheelers) {
            car.displayDetails();
            System.out.println();
        }

        // User input for comparison
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the type of vehicle to compare (2 for Two Wheeler, 4 for Four Wheeler): ");
        int choice = scanner.nextInt();

        // Display comparison result
        System.out.println("\nSelected Vehicle to Buy:");
        if (choice == 2) {
            System.out.print("Enter the index of the Two Wheeler to buy: ");
            int index = scanner.nextInt();
            twoWheelers.get(index).displayDetails();
        } else if (choice == 4) {
            System.out.print("Enter the index of the Four Wheeler to buy: ");
            int index = scanner.nextInt();
            fourWheelers.get(index).displayDetails();
        } else {
            System.out.println("Invalid choice! Please enter 2 for Two Wheeler or 4 for Four Wheeler.");
        }

        scanner.close();
    }
}
