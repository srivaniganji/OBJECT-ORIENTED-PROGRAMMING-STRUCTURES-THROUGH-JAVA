class Vehicle {
    int maxSpeed = 100;
}

class Car extends Vehicle {
    int maxSpeed = 200;

    void getSpeed() {
        System.out.println("Max Speed of Child Class = " + maxSpeed); // Accesses local class variables
        System.out.println("Max Speed from the Parent Class = " + super.maxSpeed); // Accesses the values from parent
                                                                                   // class
    }
}

public class SuperKeyword {
    public static void main(String[] args) {
        Car C = new Car();
        C.getSpeed();
    }
}
