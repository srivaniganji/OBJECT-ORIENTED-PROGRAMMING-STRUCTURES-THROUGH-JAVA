//Print the Maximum number among the given two integers;

import java.util.*;

public class Maximum {

    public static int MaxNumber(int a, int b) {
        if (a > b)
            return a;
        return b;
    }

    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.print("Enter a: ");
        int a = In.nextInt();
        System.out.print("Enter b: ");
        int b = In.nextInt();
        System.out.println("Greater Number = " + MaxNumber(a, b));
        In.close();
    }
}
