import java.util.*;

public class Vectors {
    public static void main(String args[]) {

        // Creating an empty vector
        // Vector<String> v = new Vector<String>(); //default vector initialisation
        // Vector<String> v = new Vector<String>(5); //With initial capacity specified
        Vector<String> v = new Vector<String>(2, 10);

        // Current Capacity
        System.out.println("Capacity just after initialisation : " + v.capacity());

        // Current Size
        System.out.println("Size just after initialisation : " + v.size());

        // Adding elements to the vector
        v.add("One");
        v.add("Two");
        v.add("Three");
        v.add("Five");
        v.add("Six");

        // Printing all the elements
        System.out.println("Vector of Strings : " + v);

        // Current Capacity
        System.out.println("Capacity after insertion : " + v.capacity());

        // Current Size
        System.out.println("Size after insertion : " + v.size());

        // Insert elements at index
        v.insertElementAt("Four", 3);

        System.out.println("Vector of Strings after Insertion : " + v);

        // Add all elements at a time at a given position
        v.addAll(v);

        // Printing first element in the Vector
        System.out.println("First element in the Vector : " + v.firstElement());

        // Printing last element
        System.out.println("Last element in the Vector : " + v.lastElement());

        System.out.println("Element at index 4 : " + v.elementAt(4));

        // Remove element at a position
        v.remove(2);

        System.out.println("Vector of Strings after removing element : " + v);

        // Clear all elements
        v.clear();
        System.out.println("Vector of Strings after clear : " + v);
        System.out.println("Size after clear : " + v.size());

        // Set new size
        v.setSize(8);

        System.out.println("Size after setting the size : " + v.size());

    }
}