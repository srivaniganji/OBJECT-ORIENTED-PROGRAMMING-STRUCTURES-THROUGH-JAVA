/*Write a java program to find whether given number is Palindrome or not. */

import java.util.*;

public class Palindrome {

    public int reverse(int n) {
        int rev = 0;
        while (n > 0) {
            rev = rev * 10 + n % 10;
            n /= 10;
        }
        return rev;
    }

    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.print("Enter number: ");
        int n = In.nextInt();
        Palindrome palindrome = new Palindrome();
        int rev = palindrome.reverse(n);
        if (rev == n)
            System.out.println("Palindrome!");
        else
            System.out.println("Not Palindrome!");
        In.close();
    }
}
