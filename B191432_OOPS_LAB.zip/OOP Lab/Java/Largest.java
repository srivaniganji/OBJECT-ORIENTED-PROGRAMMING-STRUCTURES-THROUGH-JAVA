/*Write an application that declares 5 integers, determines and prints the largest and smallest in the group. */

import java.util.*;

public class Largest {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.print("Enter first number: ");
        int a = In.nextInt();
        int maxi = a;
        int mini = a;
        for (int i = 0; i < 4; i++) {
            System.out.print("Enter next number: ");
            a = In.nextInt();
            if (a > maxi)
                maxi = a;
            if (a < mini)
                mini = a;
        }
        System.out.println("Among 5 integers, Largest = " + maxi + " Smallest = " + mini);
        In.close();
    }
}
