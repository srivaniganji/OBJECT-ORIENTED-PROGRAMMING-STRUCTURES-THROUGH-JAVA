/*Write a program to enter the numbers till the user wants and at the end it should 
 * display the count of positive negative and zeroes;*/

import java.util.*;

public class Tonality {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        int positive = 0;
        int negative = 0;
        int zeroes = 0;
        System.out.println("\n<--Enter -1 to exit-->\n");
        int n;
        do {
            System.out.print("Enter number: ");
            n = In.nextInt();
            if (n == 0)
                zeroes++;
            else if (n > 0)
                positive++;
            else
                negative++;
        } while (n != -1);
        System.out.println("\nNumber of positive numbers entered = " + positive + " negative numbers entered = "
                + negative + " zeroes entered = " + zeroes + "\n");
        In.close();
    }
}
