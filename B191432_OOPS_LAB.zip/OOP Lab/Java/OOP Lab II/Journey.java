//Suggest the Car for the Journey

class Car {
    String company, color;
    double mileage, speed;

    Car(String company, String color, double mileage, double speed) {
        this.company = company;
        this.color = color;
        this.mileage = mileage;
        this.speed = speed;
    }

    double getMileage() {
        return mileage;
    }

    double getSpeed() {
        return speed;
    }

    String getColor() {
        return color;
    }

    String getCompany() {
        return company;
    }
}

public class Journey {
    public static void main(String args[]) {
        Car Ford = new Car("Ford", "Maroon", 25.5, 216);
        Car Toyota = new Car("Toyota", "Black", 23, 170);
        Car VolkWagon = new Car("VolksWagon", "White", 21.49, 250);
        double r1 = Ford.mileage / Ford.speed;
        double r2 = Toyota.mileage / Toyota.speed;
        double r3 = VolkWagon.mileage / VolkWagon.speed;
        if (r1 > r2 && r1 > r3)
            System.out.println("Suggested Car for the Journey: Ford");
        else if (r2 > r1 && r2 > r3)
            System.out.println("Suggested Car for the Journey: Toyota");
        else
            System.out.println("Suggested Car for the Journey: VolkWagon");
    }
}
