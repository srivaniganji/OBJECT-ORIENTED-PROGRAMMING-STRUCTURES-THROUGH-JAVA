//TV

class TV {
    int channel;
    int volume;
    boolean isOn;

    TV() {
        isOn = true;
        channel = 1;
        volume = 10;
        System.out.println("TV Started!");
    }

    // turn ON
    void turnOn() {
        isOn = true;
    }

    // turn OFF
    void turnOff() {
        isOn = false;
    }

    // set channel
    void setChannel(int channel) {
        this.channel = channel;
    }

    // set volume
    void setVolume(int volume) {
        this.volume = volume;
    }

    // channel UP
    void channelUp() {
        channel++;
    }

    // channel DOWN
    void channelDown() {
        channel--;
    }

    // volume UP
    void volumeUp() {
        volume++;
    }

    // volume DOWN
    void volumeDown() {
        volume--;
    }

    boolean isStarted() {
        return isOn;
    }

    int getChannel() {
        return channel;
    }

    int getVolume() {
        return volume;
    }
}

public class Television {
    public static void main(String args[]) {
        TV tv = new TV();
        tv.isStarted();
        System.out.println("TV channel = " + tv.getChannel());
        System.out.println("TV volume = " + tv.getVolume());
        tv.setChannel(40);
        tv.setVolume(20);
        tv.channelUp();
        tv.volumeDown();
        System.out.println("Current TV channel = " + tv.getChannel());
        System.out.println("Current TV volume = " + tv.getVolume());
    }
}
