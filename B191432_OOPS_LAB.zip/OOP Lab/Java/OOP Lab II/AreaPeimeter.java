//Find the Area and Perimeter of the Circle

class Circle {
    int radius;

    Circle(int radius) {
        this.radius = radius;
    }

    // Area
    double getArea() {
        return Math.PI * radius * radius;
    }

    // Perimeter
    double getPerimeter() {
        return 2 * Math.PI * radius;
    }
}

class AreaPeimeter {
    public static void main(String args[]) {

        // Circle: radius=5
        System.out.println("Circle 1");
        Circle C1 = new Circle(5);
        System.out.println("Area = " + C1.getArea());
        System.out.println("Perimeter = " + C1.getPerimeter());

        // Circle: radius=10
        System.out.println("Circle 2");
        Circle C2 = new Circle(10);
        System.out.println("Area = " + C2.getArea());
        System.out.println("Perimeter = " + C2.getPerimeter());

        // Circle: radius=15
        System.out.println("Circle 3");
        Circle C3 = new Circle(15);
        System.out.println("Area = " + C3.getArea());
        System.out.println("Perimeter = " + C3.getPerimeter());
    }
}