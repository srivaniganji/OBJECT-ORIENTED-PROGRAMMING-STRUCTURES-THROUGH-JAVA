//Suggest the Dog to the buyer in a Kennel

class Dog {
    String name, breed, color, type;
    double height;

    Dog(String name, String breed, String color, String type, double height) {
        this.name = name;
        this.breed = breed;
        this.color = color;
        this.type = type;
        this.height = height;
    }

    String getBreed() {
        return breed;
    }

    String getName() {
        return name;
    }

    String getColor() {
        return color;
    }

    String getType() {
        return type;
    }

    double getHeight() {
        return height;
    }
}

public class DogBuyer {
    public static void main(String args[]) {
        Dog d[] = new Dog[3];
        d[0] = new Dog("Snoopy", "Pomerin", "White", "gaurd", 1);
        d[1] = new Dog("Rocky", "Lab", "Brown", "Sniffer", 3);
        d[2] = new Dog("Snowy", "G.Sheperd", "Black", "Sheperd", 4);
        System.out.println("--Details of Dogs in the Store--");
        for (int i = 0; i < 3; i++) {
            System.out.println("\nDog " + (i + 1));
            System.out.println("Name: " + d[i].getName());
            System.out.println("Breed: " + d[i].getBreed());
            System.out.println("Color: " + d[i].getColor());
            System.out.println("Height: " + d[i].getHeight());
            System.out.println("Type: " + d[i].getType());
        }
    }
}
