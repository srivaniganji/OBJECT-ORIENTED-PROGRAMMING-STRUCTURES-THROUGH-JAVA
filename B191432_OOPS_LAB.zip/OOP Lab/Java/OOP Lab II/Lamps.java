//Switch on/off the led light and switch on/off the halogen light

class Lamp {
    boolean isOn;
    String lampType;

    Lamp(boolean isOn) {
        this.isOn = isOn;
    }

    // turn ON
    void turnOn() {
        isOn = true;
    }

    // turn OFF
    void turnOff() {
        isOn = false;
    }

    boolean getStatus() {
        return isOn;
    }
}

public class Lamps {
    public static void main(String args[]) {
        Lamp led = new Lamp(false);
        Lamp halogen = new Lamp(false);
        led.turnOn();
        halogen.turnOn();
        led.turnOff();
        System.out.println("LED isOn: " + led.getStatus());
        System.out.println("Halogen isOn: " + halogen.getStatus());
    }
}
