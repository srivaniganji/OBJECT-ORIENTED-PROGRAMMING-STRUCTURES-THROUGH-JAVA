
//import java.util.*;
import java.util.Arrays;

class Person {
    String name;
    String address;

    void addPerson(String name, String address) {
        this.name = name;
        this.address = address;
    }

    void printPerson() {
        System.out.println(name + " " + address);
    }

    void setName(String name) {
        this.name = name;
    }

    void setAddress(String address) {
        this.address = address;
    }

    String getName() {
        return name;
    }

    String getAddress() {
        return address;
    }
}

class Student extends Person {
    int numCourses;
    String[] Courses = {};
    int[] Grades = {};

    void addStudent(String name, String address) {
        this.name = name;
        this.address = address;
    }

    void printStudent() {
        System.out.println(name + " " + address);
    }

    void addCourseGrade(String course, int grade) {
        String newCourses[] = new String[numCourses + 1];
        for (int i = 0; i < numCourses; i++) {
            newCourses[i] = Courses[i];
        }
        newCourses[numCourses] = course;
        int[] newGrades = new int[numCourses + 1];
        for (int i = 0; i < numCourses; i++) {
            newGrades[i] = Grades[i];
        }
        newGrades[numCourses] = grade;
    }

    void printGrades() {
        System.out.print("Grades : ");
        for (int i = 0; i < numCourses; i++) {
            System.out.print(Grades[i] + " ");
        }
    }

    double getAverageGrade() {
        double sum = 0;
        for (int i = 0; i < numCourses; i++) {
            sum += Grades[i];
        }
        return sum / numCourses;
    }
}

class Teacher extends Person {
    int numCourses;
    String[] Courses = {};

    void addTeacher(String name, String address) {
        this.name = name;
        this.address = address;
    }

    void printTeacher() {
        System.out.println(name + " " + address);
    }

    boolean addCourse(String course) {
        if (Arrays.asList(Courses).contains(course))
            return false;
        String newCourses[] = new String[numCourses + 1];
        for (int i = 0; i < numCourses; i++) {
            newCourses[i] = Courses[i];
        }
        newCourses[numCourses] = course;
        return true;
    }

    boolean removeCourse(String course) {
        if (!Arrays.asList(Courses).contains(course))
            return false;
        return true;
    }
}

public class StudentTeacher {

    public static void main(String args[]) {

        Student s = new Student();
        s.addStudent("Srivani", "Devarakonda");
        s.printStudent();
        s.addCourseGrade("Maths", 10);
        s.addCourseGrade("Science", 8);
        s.addCourseGrade("English", 9);
        s.printGrades();
        System.out.println("Average Grade = " + s.getAverageGrade());

        Teacher t = new Teacher();
        t.addTeacher("John", "US");
        t.printTeacher();
        System.out.println("Course Added: " + t.addCourse("Maths"));
        System.out.println("Course removed: " + t.removeCourse("Science"));
    }

}
