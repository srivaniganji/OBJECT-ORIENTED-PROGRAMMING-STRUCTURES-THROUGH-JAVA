class Pen {
    String color;
    String type;

    public void printColor() {
        System.out.println(this.color);
    }

    public void printType() {
        System.out.println(this.type);
    }

    public void print() {
        System.out.println("Writing something..");
    }
}

public class Pens {
    public static void main(String args[]) {
        Pen pen1 = new Pen();
        pen1.color = "Blue";
        pen1.type = "Gel Pen";

        Pen pen2 = new Pen();
        pen2.color = "Black";
        pen2.type = "Ball Point Pen";

        System.out.println("--Pen1--");
        pen1.printColor();
        pen1.printType();
        pen1.print();
        System.out.println("--Pen2--");
        pen2.printColor();
        pen2.printType();
        pen2.print();
    }
}