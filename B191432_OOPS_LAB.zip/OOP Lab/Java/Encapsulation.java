class Human {
    private int age;
    private String name;

    // Constructor for Human Class : Non-Parameterized
    public Human() {
        age = 20;
        name = "Srivani";
    }

    // Constructor for Human Class : Parameterized
    public Human(int age, String name) {
        this.age = age;
        this.name = name;
    }

    // Copy Constructor
    public Human(Human h) {
        this.age = h.age;
        this.name = h.name;
    }

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

    void setAge(int age) {
        this.age = age;
    }

    void setName(String name) {
        this.name = name;
    }
}

public class Encapsulation {
    public static void main(String args[]) {

        // Examples for Non-parameterized
        Human h = new Human();

        System.out.println(h.getName() + " " + h.getAge());

        h.setName("RajaSri");
        h.setAge(17);
        System.out.println(h.getName() + " " + h.getAge());

        // Examples for Parameterized Consturctors
        Human h1 = new Human(15, "Harshini");

        System.out.println(h1.getName() + " " + h1.getAge());

    }
}
