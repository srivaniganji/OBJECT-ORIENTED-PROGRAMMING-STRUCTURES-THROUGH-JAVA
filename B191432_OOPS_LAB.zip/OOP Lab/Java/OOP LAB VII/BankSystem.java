/*
 Case study : Bank management system
Define a package bank.
 Include following functionalities as abstract methods in an interface
abstract  credentialsCheck(String Username, String password); 
abstract  credit( );
abstract  debit( );
abstract  displayBalance();
abstract  exit();
Until user selects exit he can perform any of the above operations.
Handle the following exceptions during the transaction
1. Username and password mismatch. // display error message and continue;
2. If debit amount exceeds available balance. // display error message and
continue; */

import java.util.*;

import Bank.BankOperations;
import Bank.InsufficientBalanceException;

public class BankSystem {
    public static void main(String args[]) {
        try (Scanner In = new Scanner(System.in)) {
            String username, password;
            System.out.print("Enter username: ");
            username = In.nextLine();
            System.out.print("Enter password: ");
            password = In.nextLine();

            System.out.println("\n--Welcome to Srivani's Bank--");

            BankOperations b = new BankOperations("rgukt", "123", 1000.00);

            System.out.println(" 1 to credit amount");
            System.out.println(" 2 to debit amount");
            System.out.println(" 3 to display amount");
            System.out.println(" 4 to exit()");

            while (true) {
                if (!b.credentialsCheck(username, password))
                    System.out.println("Username or Password mismatch. Please try again.");
                System.out.print("\nChoose an option: ");

                int choice = In.nextInt();

                switch (choice) {
                    case 1:
                        System.out.print("Enter amount to credit: ");
                        double cAmount = In.nextInt();
                        b.credit(cAmount);
                        break;
                    case 2:
                        System.out.print("Enter amount to debit: ");
                        int dAmount = In.nextInt();
                        try {
                            b.debit(dAmount);
                        } catch (InsufficientBalanceException e) {
                            // e.printStackTrace();
                            System.out.println(e);
                        }
                        break;
                    case 3:
                        b.displayBalance();
                        break;
                    case 4:
                        b.exit();
                        break;
                    default:
                        System.out.println("Invalid Choice. Please try again.");
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
