package Booking;

import javax.naming.LimitExceededException;

public interface TicketBookingSystem {
    void bookTickets(int berths, String preferredClass) throws LimitExceededException;

    void allocatedBerths();
}
