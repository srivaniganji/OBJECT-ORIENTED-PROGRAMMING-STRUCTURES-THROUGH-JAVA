package Booking;

import javax.naming.LimitExceededException;

public class TrainTicketBooking {
    private int MAX_BERTHS = 70;
    private int CAPACITY = 70;
    private int MAX_ALLOT = 6;

    public void bookTickets(int berths, String preferredClass) throws LimitExceededException {
        if (berths > MAX_ALLOT) {
            throw new LimitExceededException();
        } else {
            allotBerths(preferredClass);
        }
    }

    public void allotBerths(String preferredClass) {

    }
}
