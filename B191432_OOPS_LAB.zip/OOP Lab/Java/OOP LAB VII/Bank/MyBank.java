package Bank;

public interface MyBank {
    abstract boolean credentialsCheck(String Username, String Password);

    abstract void credit(double amount);

    abstract void debit(double amount) throws InsufficientBalanceException;

    abstract void displayBalance();

    abstract void exit();
}
