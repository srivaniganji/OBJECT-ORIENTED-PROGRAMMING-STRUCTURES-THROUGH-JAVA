package Bank;

public class BankOperations implements MyBank {
    public String username;
    public String password;
    private double balance;

    public BankOperations(String username, String password, double balance) {
        this.username = username;
        this.password = password;
        this.balance = balance;
    }

    public boolean credentialsCheck(String enteredUsername, String enteredPassword) {
        if (this.username.equals(enteredUsername) && this.password.equals(enteredPassword))
            return true;
        return false;
    }

    public void credit(double amount) {
        this.balance += amount;
        System.out.println("Amount incremented by " + amount);
        displayBalance();
    }

    public void debit(double amount) throws InsufficientBalanceException {
        if (amount > this.balance) {
            throw new InsufficientBalanceException("Insufficienct balance. Debited amount exceeds account balance.");
        }
        this.balance -= amount;
        System.out.println("Amount decremented by " + amount);
        displayBalance();

    }

    public void displayBalance() {
        System.out.println("Current balance = " + this.balance);
    }

    public void exit() {
        System.out.println("Account exited. ThankYou for visiting!");
        System.exit(0);
    }
}
