package Audit;

public class TaxFraudException extends Exception {
    TaxFraudException(String message) {
        super(message);
    }
}