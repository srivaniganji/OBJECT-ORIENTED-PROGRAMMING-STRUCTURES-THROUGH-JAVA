package Audit;

public class TaxFraud implements TaxAudit {
    public double totalIncome;
    public double totalExpenditure;
    public double taxPaid;

    public TaxFraud(double totalIncome, double taxPaid) {
        this.totalIncome = totalIncome;
        this.taxPaid = taxPaid;
        this.totalExpenditure = 0.0;
    }

    public void taxChecker(double totalIncome, double taxPaid) throws TaxFraudException {
        double calculatedTax = 0.1 * (totalIncome - totalExpenditure);
        if (taxPaid != calculatedTax) {
            try {
                throw new TaxFraudException("\nTax fraud detected! You have to pay: $" + calculatedTax);
            } catch (TaxFraudException e) {
                System.out.println(e.getMessage());
            }
        } else {
            System.out.println("\nTax calculation is correct. No fraud detected.");
        }
    }

    public void taxPaid(double amount) {
        this.taxPaid = amount;
    }

    public void homeExpenditure(double amount) {
        totalExpenditure += amount;
    }

    public void healthExpenditure(double amount) {
        totalExpenditure += amount;
    }

    public void vehicleExpenditure(double amount) {
        totalExpenditure += amount;
    }

    public void personalFamilyExpenditure(double amount) {
        totalExpenditure += amount;
    }

    public void miscellaneousExpenditure(double amount) {
        totalExpenditure += amount;
    }
}
