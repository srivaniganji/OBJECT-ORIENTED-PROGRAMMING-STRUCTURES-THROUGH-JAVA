/*
Write a Java program that reads a numeric input from the user. Call the input
method in a try block and catch the specific exception that the input method would
throw if the user entered a non-numeric input.
Hint : import java.util.InputMismatchException;
 */

import java.util.*;

public class NumericException {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        try {
            System.out.print("Enter your favorite number: ");
            int fav = In.nextInt();
            System.out.println("Wow! I too love.." + fav);
        } catch (Exception e) {
            System.out.println(e);
        }
        In.close();
    }
}
