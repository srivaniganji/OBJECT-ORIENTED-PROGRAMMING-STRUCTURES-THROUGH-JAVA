/*
Case study : Tax fraud detection
Define package audit.
Include following functionalities as abstract methods in an interface.
abstract  taxChecker ();
abstract  taxPaid();
abstract  homeExpenditure();
abstract  healthExpenditure();
abstract  vehicleExpenditure();
abstract  personalFamilyExpenditure();
abstract  miscellaneousExpenditure();
Inputs : all the above expenditures, TotalIncome and Taxpaid
He/She has to pay 10% of ( TotalIncome- (all other expenditures)) on mismatch
throw an exception as fraud and display message, how much he/she has to pay. 
*/

import Audit.*;

class TaxFraudDetection {
    public static void main(String[] args) {
        TaxFraud taxAudit = new TaxFraud(1000, 500);

        taxAudit.homeExpenditure(100);
        taxAudit.healthExpenditure(200);
        taxAudit.vehicleExpenditure(50);
        taxAudit.personalFamilyExpenditure(150);
        taxAudit.miscellaneousExpenditure(100);

        taxAudit.taxPaid(50);

        try {
            taxAudit.taxChecker(taxAudit.totalIncome, taxAudit.taxPaid);
        } catch (TaxFraudException e) {
            System.out.println(e);
        }
    }
}
