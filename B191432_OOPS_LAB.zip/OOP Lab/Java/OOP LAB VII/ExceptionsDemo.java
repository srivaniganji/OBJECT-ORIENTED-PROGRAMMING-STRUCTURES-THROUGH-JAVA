/*
Mr.Bean claims himself as efficient software developer and claims that his
application can handle the following exceptions
ArithmeticException, NullPointerExceptions, ArrayIndexOutOfBoundsException,
IOException etc., . You being the Tester test the application to validate his claims.
Hint : Develop any application that handle’s all the exceptions stated above. */

import java.io.IOException;

public class ExceptionsDemo {

    static int divide(int numerator, int denominator) {
        return numerator / denominator;
    }

    static void getIOException() throws IOException {
        throw new IOException();
    }

    public static void main(String args[]) {
        try {
            int result = divide(10, 10);
            System.out.println(result);

            String s = "null";
            int length = s.length();
            System.out.println(length);

            int[] array = { 1, 2, 3 };
            int value = array[2];
            System.out.println(value);

            getIOException();
        } catch (ArithmeticException e) {
            System.out.println(e);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(e);
        } catch (IOException e) {
            System.out.println(e);
        } catch (NullPointerException e) {
            System.out.println(e);
        } finally {
            System.out.println("Exceptions caught!");
        }
    }
}
