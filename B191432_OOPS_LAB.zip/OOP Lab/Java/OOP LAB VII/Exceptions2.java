/*
 * Write a program that shows that the order of the catch blocks is important. If you try to    
 * catch a superclass exception type before a subclass type, the compiler  should generate      
 * errors. 
 */

public class Exceptions2 {
    public static void main(String args[]) {
        try {
            System.out.println(10 / 0);
            String s = null;
            System.out.println(s.length());
        } catch (ArithmeticException e) {
            System.out.println(e);
        } catch (NullPointerException e) {
            System.out.println(e);
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            System.out.println("In finally block!");
        }
    }
}
