/*
Passengers can reserve their tickets in train. It has two First class A/C coaches
(B1, B2), two sleeper coaches(s1, s2) with capacity 70 each. 
Prompt the user to enter the required berths and class(A/c or sleeper), allocate
berths randomly and display the Confirmed berths after booking.
Under following conditions throw an exception as “You may be an Agent” and
deny the request.
1. If the number of required berths are above 6.
2. If he/she is booking tickets by selecting different classes (A/c or sleeper) */

import java.util.*;

public class TicketBooking {
    public static void main(String args[]) {
        Scanner In = new Scanner(System.in);
        System.out.println("Enter number of berths required: ");
        int requiredBerths = In.nextInt();
        System.out.println("Preferred class: ");
        String preferredClass = In.nextLine();

        bookTickets(requiredBerths, preferredClass);

        In.close();
    }
}
