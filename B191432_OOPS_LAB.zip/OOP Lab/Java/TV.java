import TVRemote.Remote;
import TVRemote.RemoteOperations;

public class TV {
	public static void main(String args[]){
		RemoteOperations r = new RemoteOperations();
		r.switchOn();
		r.setChannel(2);
		r.switchOff();
	}
}