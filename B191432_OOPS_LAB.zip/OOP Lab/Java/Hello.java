/*Write a java program to print "Hello World" */

public class Hello {

    public void test() {
        System.out.println("Welcome to Java");
    }

    public static void main(String args[]) {
        System.out.println("Hello World!");
        Hello hello = new Hello();
        hello.test();
    }
}